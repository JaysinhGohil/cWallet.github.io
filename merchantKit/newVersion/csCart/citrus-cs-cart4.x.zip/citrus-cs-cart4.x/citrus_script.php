<?php

set_include_path(DIR_ROOT . '/payments/citrus/lib/'.PATH_SEPARATOR.get_include_path());
set_include_path('./citrus/lib/'.PATH_SEPARATOR.'./lib/'.PATH_SEPARATOR.'./citrus/'.PATH_SEPARATOR.get_include_path());
require_once ('CitrusPay.php');
require_once ('Zend/Crypt/Hmac.php');

function generateHmacKey($data, $apiKey=null){
	$hmackey = Zend_Crypt_Hmac::compute($apiKey, "sha1", $data);
	return $hmackey;
}
if (!empty($_REQUEST['modecitrus'])) {

	require_once './init_payment.php';

	$order_id="";
	$txnid = "";
	$txnmsg = "";
	$txnstatus="";
	
	if(isset($_REQUEST['order_id'])) $order_id=$_REQUEST['order_id'];
	if(isset($_POST['TxId'])) $txnid = $_POST['TxId'];
	if(isset($_POST['TxStatus'])) $txnstatus = $_POST['TxStatus'];
	if(isset($_POST['TxMsg'])) $txnmsg = $_POST['TxMsg'];
	
	$pp_response = array();
	$order_info = fn_get_order_info($order_id, true);

	//verify sig
	$data=$_POST['TxId'].$_POST['TxStatus'].$_POST['amount'].$_POST['pgTxnNo'].$_POST['issuerRefNo'].$_POST['authIdCode'].$_POST['firstName'].$_POST['lastName'].$_POST['pgRespCode'].$_POST['addressZip'];
	$respSig=$_POST['signature'];
	$api_key = $_SESSION['capi_key'];	
	$pg = $_SESSION['cpg'];
	CitrusPay::setApiKey($api_key, $pg);
	if($respSig != generateHmacKey($data,CitrusPay::getApiKey()))
		$txnstatus="FORGED";


	if($txnstatus == "SUCCESS"){
		$pp_response['order_status'] = 'O';
		$pp_response['reason_text'] = '';
		$pp_response['transaction_id'] = $txnid;
		if ($order_info['status'] == 'N') {
			fn_change_order_status($order_id, 'O', '', false);
		}
		fn_update_order_payment_info($order_id, $pp_response);
		fn_order_placement_routines($order_id, false);
	}else{
		$pp_response['order_status'] = 'F';
		$pp_response['reason_text'] =  $txnmsg;
		$pp_response['transaction_id'] = $txnid;
		if ($order_info['status'] == 'N') {
			fn_change_order_status($order_id, 'F', '', false);
		}
		fn_finish_payment($order_id, $pp_response, false);
		fn_order_placement_routines($order_id,false);
	}
} else {
	if ( !defined('AREA') ) { die('Access denied'); }

$vurl = $processor_data['params']['vurl'];
$m_key = $processor_data['params']['m_key'];
$api_key = $processor_data['params']['api_key'];
$pg = $processor_data['params']['payment_gateway'];
$_SESSION['capi_key'] = $api_key;
$_SESSION['cpg'] = $pg;
$current_location = Registry::get('config.current_location');
$currency = $processor_data['params']['currency_code'];
$merchantTxnId = rand(1,1000).$order_id;
$addressState = $order_info['b_state'];
$addressCity = $order_info['b_city'];
$addressStreet = $order_info['b_address'];
$addressCountry = $order_info['b_country'];
$addressZip = $order_info['b_zipcode'];
$firstName = $order_info['b_firstname'];
$lastName = $order_info['b_lastname'];
$phoneNumber = $order_info['b_phone'];
$email = $order_info['email'];
$paymentMode = "NET_BANKING"; // CREDIT_CARD // DEBIT_CARD
$returnUrl ="$current_location/payments/citrus_script.php?modecitrus=1&order_id=$order_id";
$orderAmount = $order_info['total'];
$data = "$vurl$orderAmount$merchantTxnId$currency";
CitrusPay::setApiKey($api_key, $pg);
$secSignature = generateHmacKey($data,CitrusPay::getApiKey());
$action = CitrusPay::getCPBase()."$vurl";  
$time = time()*1000;

$msg = fn_get_lang_var('text_cc_processor_connection');
$msg = str_replace('[processor]', 'Citrus', $msg);

echo <<<EOT
<html>
<body onLoad="document.process.submit();"  >
<form action="{$action}" method="POST" name="process" id="process">
	<input name="merchantAccessKey" type="hidden" value="{$m_key}" />
	<input  name="merchantTxnId" type="hidden" value="{$merchantTxnId}" />
	<input  name="addressState" type="hidden" value="{$addressState}" />
	<input  name="addressCity" type="hidden" value="{$addressCity}" />
	<input name="addressStreet1" type="hidden" value="{$addressStreet}" />
	<input name="addressCountry" type="hidden" value="{$addressCountry}" />
	<input name="addressZip" type="hidden" value="{$addressZip}" />
	<input name="firstName" type="hidden" value="{$firstName}" />
	<input  name="lastName" type="hidden" value="{$lastName}" />
	<input name="phoneNumber" type="hidden" value="{$phoneNumber}" />
	<input name="email" type="hidden" value="{$email}" />
	<input name="returnUrl" type="hidden" value="{$returnUrl}" />
	<input name="orderAmount" type="hidden" value="{$orderAmount}" />
	<input name="paymentMode" type="hidden" value="{$paymentMode}" />
	<input type="hidden" name="currency" value="{$currency}" />
	<input type="hidden" name="reqtime" value="{$time}" /> 
	<input type="hidden" name="secSignature" value="{$secSignature}" />
	</form>
	<div align=center>{$msg}</div>
 </body>
</html>
EOT;
}
exit;
?>