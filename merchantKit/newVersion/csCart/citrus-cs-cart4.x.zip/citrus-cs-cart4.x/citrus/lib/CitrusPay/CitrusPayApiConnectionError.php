<?php

class CitrusPay_ApiConnectionError extends CitrusPay_Error
{
}
