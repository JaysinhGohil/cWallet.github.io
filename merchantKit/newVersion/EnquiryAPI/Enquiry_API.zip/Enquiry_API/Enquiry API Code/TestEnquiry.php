﻿<?php 

set_include_path('../lib'.PATH_SEPARATOR.get_include_path());
require_once('../lib/Citruspay.php');
	$secretKey = "9cb8adb33795e35b614dc48615cd2187f23d007e"; // Needs to be change with your secret key
	$merchantAccessKey = "SBBQ6ZMAR9NQ3KWK5B3B";  // Needs to be change with your access key
	$transactionId = "123444444"; //Needs to be change with your merchant transaction id	
		
	$tarr = array(
			"merchantAccessKey" => "$merchantAccessKey",
			"transactionId" => "$transactionId",
			
	);
	CitrusPay::setApiKey($secretKey,'sandbox');//Change "sandbox" to "production" once you go live.
	$response = Enquiry::create($tarr,CitrusPay::getApiKey());	
	if($response->get_resp_code() == 200)
	{
		$enquiry = $response->get_enquiry();		 		
		for($i=0;$i < count($enquiry);++$i)
		{
			$enqObj = $enquiry[$i];
			$html = "<li>";
			$html .= "<div>";
			$html .= "<div> TXN Response Code : ".$enqObj->get_resp_code()."</div>";
			$html .= "<div> TXN Response Message : ".$enqObj->get_resp_msg()."</div>";
			$html .= "<div> TXN ID : ".$enqObj->get_txn_id()."</div>";
			$html .= "<div> AUTH ID : ".$enqObj->get_auth_id_code()."</div>";
			$html .= "<div> PG TXN ID : ".$enqObj->get_pg_txn_id()."</div>";
			$html .= "<div> RRN : ".$enqObj->get_rrn()."</div>";
			$html .= "<div> TXN TYPE : ".$enqObj->get_txn_type()."</div>";
			$html .= "<div> TXN DATE : ".$enqObj->get_txn_date_time()."</div>";
			$html .= "<div> Amount : ".$enqObj->get_amount()."</div>";
			$html .= "<div> Transaction Gateway : ".$enqObj->get_txn_gateway()."</div>";
			$html .= "<div> Payment Mode : ".$enqObj->get_payment_mode()."</div>";
			$html .= "<div> Issuer Code : ".$enqObj->get_issuer_code()."</div>";
			$html .= "<div> Masked Card Number : ".$enqObj->get_masked_card_number()."</div>";
			$html .= "<div> Card Type : ".$enqObj->get_card_type()."</div>";
			$html .= "</div>";
			$html .= "</li>";
		}
		$html .= "</ul>";
		$html .= "</div>";
	}
	else
	{
		$html = "<p>Response Code is ".$response->get_resp_code()."</p>";
		$html .= "<p>Response Message is ".$response->get_resp_msg()."</p>";
	}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>CitrusPay: Test Enquiry</title>

</head>
<body>
	<?php 				
		echo $html;				
	?>
</body>
</html>
