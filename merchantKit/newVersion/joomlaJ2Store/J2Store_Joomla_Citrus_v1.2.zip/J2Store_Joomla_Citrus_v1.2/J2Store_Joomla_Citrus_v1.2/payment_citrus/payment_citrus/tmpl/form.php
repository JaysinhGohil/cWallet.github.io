<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - J2 Store v 3.0 - Payment Plugin - SagePay
 * --------------------------------------------------------------------------------
 * @package		Joomla! 2.5x
 * @subpackage	J2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

defined('_JEXEC') or die('Restricted access'); ?>
<div class="note">
    <b><?php echo JText::_( "J2STORE_CITRUS_PAYMENT_STANDARD_FORM_MESSAGE_1" ); ?></b>
	<br/><br/>
	<?php echo JText::_( "J2STORE_CITRUS_PAYMENT_STANDARD_FORM_MESSAGE_2" ); ?>
</div>

