<?php
/*
 * --------------------------------------------------------------------------------
   Weblogicx India  - J2 Store v 3.0 - Payment Plugin - SagePay
 * --------------------------------------------------------------------------------
 * @package		Joomla! 2.5x
 * @subpackage	J2 Store
 * @author    	Weblogicx India http://www.weblogicxindia.com
 * @copyright	Copyright (c) 2010 - 2015 Weblogicx India Ltd. All rights reserved.
 * @license		GNU/GPL license: http://www.gnu.org/copyleft/gpl.html
 * @link		http://weblogicxindia.com
 * --------------------------------------------------------------------------------
*/

//no direct access
defined('_JEXEC') or die('Restricted access'); 

?>


<form action="<?php echo $vars->action ?>" method="post" name="transactionForm" id="transactionForm" >

    <div class="note">
        <?php echo JText::_( "J2STORE_CITRUS_PAYMENT_STANDARD_PREPARATION_MESSAGE" ); ?>  
        <br/><br/><br/><br/>
    </div>

    <input type='hidden' name='merchantTxnId' value='<?php echo htmlspecialchars ($vars->merchantTxnId); ?>'>
    <input type='hidden' name='merchantAccessKey' value='<?php echo htmlspecialchars ($vars->merchantAccessKey); ?>'>
    <input type='hidden' name='orderAmount' value='<?php echo htmlspecialchars ($vars->orderAmount); ?>'>
    <input type='hidden' name='currency' value='<?php echo htmlspecialchars ($vars->currency); ?>'>
    <input type='hidden' name='firstName' value='<?php echo htmlspecialchars ($vars->firstName); ?>'>
    <input type='hidden' name='lastName' value='<?php echo htmlspecialchars ($vars->lastName); ?>'>
    <input type='hidden' name='addressStreet1' value='<?php echo htmlspecialchars ($vars->addressStreet1); ?>'>
    <input type='hidden' name='addressZip' value='<?php echo htmlspecialchars ($vars->addressZip); ?>'>
    <input type='hidden' name='addressCity' value='<?php echo htmlspecialchars ($vars->addressCity); ?>'>
    <input type='hidden' name='addressState' value='<?php echo htmlspecialchars ($vars->addressState); ?>'>
    <input type='hidden' name='addressCountry' value='<?php echo htmlspecialchars ($vars->addressCountry); ?>'>
    <input type='hidden' name='email' value='<?php echo htmlspecialchars ($vars->email); ?>'>
    <input type='hidden' name='phoneNumber' value='<?php echo htmlspecialchars ($vars->phoneNumber); ?>'>
    <input type='hidden' name='paymentMode' value='<?php echo htmlspecialchars ($vars->paymentMode); ?>'>
    <input type='hidden' name='returnUrl' value='<?php echo htmlspecialchars ($vars->returnUrl); ?>'>
    <input type='hidden' name='reqtime' value='<?php echo htmlspecialchars ($vars->reqtime); ?>'>
    <input type='hidden' name='secSignature' value='<?php echo htmlspecialchars ($vars->secSignature); ?>'>
    
    <input type="submit" class="btn btn-primary button" value="<?php echo JText::_('J2STORE_CITRUS_CLICK_TO_COMPLETE_ORDER'); ?>" />

    
    <?php echo JHTML::_( 'form.token' ); ?>
</form>

<script type="text/javascript">
  //document.transactionForm.submit();
</script>