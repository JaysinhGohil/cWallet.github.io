<?php
/*
 * --------------------------------------------------------------------------------
  J2 Store - Payment Plugin - Citrus
 * --------------------------------------------------------------------------------
 * @package		Joomla! 2.5x
 * @subpackage	J2 Store
 * --------------------------------------------------------------------------------
*/

// no direct access
defined('_JEXEC') or die('Restricted access');

require_once JPATH_ADMINISTRATOR . '/components/com_j2store/library/plugins/payment.php';
require_once JPATH_ADMINISTRATOR . '/components/com_j2store/helpers/j2store.php';


set_include_path(JPATH_ROOT . DS . 'plugins' . DS . 'j2store' . DS . 'payment_citrus/citrus/lib'.PATH_SEPARATOR.get_include_path());

require_once("citrus/lib/CitrusPay.php");
require_once("citrus/lib/Zend/Crypt/Hmac.php");


class plgJ2StorePayment_citrus extends J2StorePaymentPlugin

{/**
            	 * @var $_element  string  Should always correspond with the plugin's filename, 
            	 *                         forcing it to be unique 
            	 */
  var $_element    = 'payment_citrus';
  var $sandbox    = '';
  var $vanityurl    = '';
  var $access_key = "";
  var $secret_key = "";
  var $_isLog      = false;
  
  function plgJ2StorePayment_citrus(& $subject, $config) 
  {
    parent::__construct($subject, $config);
    $this->loadLanguage( '', JPATH_ADMINISTRATOR );
    
    $this->sandbox = $this->_getParam( 'sandbox' ); 
    $this->vanityurl = $this->_getParam( 'vanityurl' );
    $this->access_key = $this->_getParam( 'access_key' );
    $this->secret_key = $this->_getParam( 'secret_key' );
    $this->sendemail = $this->_getParam( 'sendemail' );
  }


  //AA - Done
  /**
   * Prepares variables and 
   * Renders the form for collecting payment info
   * 
   * @return unknown_type
   */
  function _renderForm( $data )
  {
    $vars = new JObject();
    
    $html = $this->_getLayout('form', $vars);
    
    return $html;
  }
  
  //AA - Done
  /**
   * Verifies that all the required form fields are completed
   * if any fail verification, set 
   * $object->error = true  
   * $object->message .= '<li>x item failed verification</li>'
   * 
   * @param $submitted_values     array   post data
   * @return unknown_type
   */
  function _verifyForm( $submitted_values )
  {
    $object = new JObject();
    $object->error = false;
    $object->message = '';
    $user = JFactory::getUser();
    
    return $object;
  }
  
  
  /**
   * @param $data     array       form post data
   * @return string   HTML to display
   */
  function _prePayment( $data )
  {
    // prepare the payment form
    $vars = new JObject();
    
    //now we have everthing in the data. We need to generate some more citrus specific things.
    
    //lets get vendorname
    
    $vars->url = "index.php?option=com_j2store&view=checkout&task=confirmPayment&orderpayment_type=payment_citrus&paction=process";
    $vars->order_id = $data['order_id'];
    $vars->orderpayment_id = $data['orderpayment_id'];
    $vars->orderpayment_type = $this->_element;
    
    
    //not required $orderindexid = $this->_getOrderId($vars->order_id);          //the autonumber
    $order = $this->_getOrderInfo($vars->orderpayment_id);
    
    //set up the form
    
    $addressline = (is_null($order->billing_address_1) ? "" : trim($order->billing_address_1));
    if (isset($order->billing_address_2))
    {
      if (trim($order->billing_address_2 != ""))
        $addressline = $addressline .' '. trim($order->billing_address_2);
    }
    
    //try to use phone 2 (non mandatory), else phone 1
    if (is_null($order->billing_phone_2) || trim($order->billing_phone_2) == "")
    {
      $phone = (is_null($order->billing_phone_1) ? "" : $order->billing_phone_1);
    }
    else
    { 
      $phone = $order->billing_phone_2;
    }
    
    $j2store_params = JComponentHelper::getParams('com_j2store');
    
    CitrusPay::setApiKey($this->secret_key, $this->sandbox);        
    $vanityUrl = $this->vanityurl;
    $merchantTxnId = $vars->order_id;
    
    $currency = $data['order']->currency_code;
    
    $orderAmount = $data["orderpayment_amount"];		        
    $paymentdata = "$vanityUrl$orderAmount$merchantTxnId$currency";
    $secSignature = $this->generateHmacKey($paymentdata,CitrusPay::getApiKey());
    $action = CitrusPay::getCPBase()."$vanityUrl"; 
    
    $state = "";
    $country = "";
    
    if (is_null($order->billing_zone_id) || $order->billing_zone_id == "")
    {
      $state = "";
    }
    else
    {
      $state = $this->getZoneById($order->billing_zone_id)->zone_name;
    }
    
    if (is_null($order->billing_country_id) || $order->billing_country_id == '')
    {
      $country = "";
    }
    else
    {      
      $country = $this->getCountryById($order->billing_country_id)->country_name;
    }
    
    //$this->getCountryById($orderinfo->billing_country_id)->country_isocode_2;
    
    $vars->transactionId = $merchantTxnId;
    $vars->merchantTxnId = $merchantTxnId;
    $vars->merchantAccessKey = $this->access_key;
    $vars->orderAmount = $orderAmount;
    $vars->currency = $currency;
    $vars->firstName = $order->billing_first_name;
    $vars->lastName = $order->billing_last_name;
    $vars->addressStreet1 = $addressline;
    $vars->addressZip = (is_null($order->billing_zip) ? "" : $order->billing_zip);
    $vars->addressCity = (is_null($order->billing_city) ? "" : $order->billing_city);
    $vars->addressState = $state;
    $vars->addressCountry = $country;
    $vars->email = (isset($data['order'] ->user_email) ? $data['order'] ->user_email : "");
    $vars->phoneNumber = $phone;
    $vars->paymentMode = 'NET_BANKING';
    $vars->returnUrl = JROUTE::_ (JURI::root () . $vars->url);
    $vars->action = $action;
    $vars->reqtime =  time()*1000;
    $vars->secSignature = $secSignature;    
    
    $html = $this->_getLayout('prepayment', $vars);
    return $html;
  }
  
  /**
   * Processes the payment form
   * and returns HTML to be displayed to the user
   * generally with a success/failed message
   *  
   * @param $data     array       form post data
   * @return string   HTML to display
   */
  function _postPayment( $data )
  {
    // Process the payment        
    $vars = new JObject();
    
    $app =JFactory::getApplication();
    $paction = JRequest::getVar( 'paction' );
    
    switch ($paction)
    {     
      case 'process':
        $vars->message = $this->_process();
        $html = $this->_getLayout('message', $vars);
        $html .= $this->_displayArticle();
        break;
      default:
        $vars->message = JText::_( 'J2STORE_CITRUS_MESSAGE_INVALID_ACTION' );
        $html = $this->_getLayout('message', $vars);
        break;
    }
    
    return $html;
  }
  
  
  
  /**
   * Processes the payment
   * 
   * This method process only real time (simple) payments
   * 
   * @return string
   * @access protected
   */
  function _process()
  {
    
    $data = JRequest::get('post');
    //tamper protection
    $hash = (isset($data['TxId'])? $data['TxId']:'') . (isset($data['TxStatus'])? $data['TxStatus']:'') . (isset($data['amount'])? $data['amount']:'') . (isset($data['pgTxnNo'])? $data['pgTxnNo']:'') . (isset($data['issuerRefNo'])? $data['issuerRefNo']:'') . (isset($data['authIdCode'])? $data['authIdCode']:'') . (isset($data['firstName'])? $data['firstName']:'') . (isset($data['lastName'])? $data['lastName']:'') . (isset($data['pgRespCode'])? $data['pgRespCode']:'') . (isset($data['addressZip'])? $data['addressZip']:'');
    $sig=$data['signature'];
    CitrusPay::setApiKey($this->secret_key, $this->sandbox);
    $hash=$this->generateHmacKey($hash,CitrusPay::getApiKey());
    if($sig != "" && strcmp($sig, $hash) != 0)
    {
      return JText::_( 'J2STORE_CITRUS_INVALID_ORDER' );
    }
    
    //check if the payment was processed successfully
    return $this->_processResponse($data);       
    
  }
  
  
  /**
     * Proceeds the simple payment
     * 
     * @param string $resp
     * @param array $submitted_values
     * @return object Message object
     * @access protected
     */
  function _processResponse( $resp )
  {
    $object = new JObject();
    $object->message = '';
    $html = '';
    $errors = array();
    $payment_status = JText::_('J2STORE_INCOMPLETE');
    $user =JFactory::getUser();
    
    // Evaluate a typical response from citrus pay
    
    switch ($resp['TxStatus']) 
    {
      case 'SUCCESS':
        // Approved
        $payment_status = JText::_('J2STORE_COMPLETED');        
        break;
      
      default:
        // Declined - Error
        $payment_status = JText::_('J2STORE_DECLINED');
        $order_status = JText::_('J2STORE_INCOMPLETE');
        $errors[] = JText::_( "J2STORE_CITRUS_ERROR_PROCESSING_PAYMENT" );
        break;
    }
    
    // =======================
    // verify & create payment
    // =======================
    $orderpayment_id =  $resp['TxId'];
    
    // get order information
    F0FTable::addIncludePath( JPATH_ADMINISTRATOR.'/components/com_j2store/tables' );
    $orderpayment = F0FTable::getInstance('Order', 'J2StoreTable');
    if($orderpayment->load( array('order_id'=> $orderpayment_id))) {

      //check for exisiting things     
      $orderpayment->transaction_details  = $resp['TxMsg'];
      $orderpayment->transaction_id       = $resp['TxRefNo'];
      $orderpayment->transaction_status   = $payment_status;

      //set a default status to it
      $order_state_id = 4; // PENDING
      
      // set the order's new status and update quantities if necessary
      if (count($errors)) 
      {
        // if an error occurred 
        $order_state_id = 3; // FAILED                
      }
      else 
      {
        $order_state_id = 1; // CONFIRMED     
      }
      
      
      if($order_state_id == 1) {
        $orderpayment->payment_complete();
      } 
      else 
      {
        $orderpayment->update_status($order_state_id);
      }
      
      // save the order
      if (!$orderpayment->store())
      {
        $errors[] = $orderpayment->getError();
      } 
      else 
      {
        $orderpayment->empty_cart();
      }      
      
    }
    else
    {
      $errors[] = JText::_( "J2STORE_CITRUS_ERROR_PROCESSING_ORDER" );
    }
        
    if (empty($errors))
    {
      //$return['success']  = JText::_($this->params->get('onafterpayment', ''));
      //$return['redirect'] = JRoute::_('index.php?option=com_j2store&view=checkout&task=confirmPayment&orderpayment_type='.$this->_element.'&paction=display');
      
      $return = JText::_( "J2STORE_CITRUS_MESSAGE_PAYMENT_SUCCESS" );
      return $return;                
    }
    else
    {      
      $error = count($errors) ? implode("\n", $errors) : '';
      try
      {
        if ($this->sendemail == 'true')
        {
          $this->_sendErrorEmails($error, $orderpayment->transaction_details);
        }
      }
      catch(Exception $e)
      {
        _log("Error sending payment error email. Check settings", 'message');
      }
    }
    
    
    return count($errors) ? implode("\n", $errors) : '';

    // ===================
    // end custom code
    // ===================
  }


  //AA - Done
  /**
   * Gets a value of the plugin parameter
   * 
   * @param string $name
   * @param string $default
   * @return string
   * @access protected
   */
  function _getParam($name, $default = '') 
  {
    
    $param = $this->params->get($name, $default);
    
    return $param;
  }
  
  
  //AA - Done
  /**
   * Simple logger 
   * 
   * @param string $text
   * @param string $type
   * @return void
   */
  function _log($text, $type = 'message')
  {
    if ($this->_isLog) {
      $file = JPATH_ROOT . "/cache/{$this->_element}.log";
      $date = JFactory::getDate();
      
      $f = fopen($file, 'a');
      fwrite($f, "\n\n" . $date->toFormat('%Y-%m-%d %H:%M:%S'));
      fwrite($f, "\n" . $type . ': ' . $text);            
      fclose($f);
    }   
  }

  //AA - Done
  function generateHmacKey($data, $apiKey=null){
    $hmackey = Zend_Crypt_Hmac::compute($apiKey, "sha1", $data);
    return $hmackey;
  }	
  
  
  //AA - Done
  /**
   * Sends error messages to site administrators
   *
   * @param string $message
   * @param string $paymentData
   * @return boolean
   * @access protected
   */
  function _sendErrorEmails($message, $paymentData)
  {
    $mainframe =JFactory::getApplication();
    
    // grab config settings for sender name and email
    $config     = JComponentHelper::getParams('com_j2store');
    $mailfrom   = $config->get( 'emails_defaultemail', $mainframe->getCfg('mailfrom') );
    $fromname   = $config->get( 'emails_defaultname', $mainframe->getCfg('fromname') );
    $sitename   = $config->get( 'sitename', $mainframe->getCfg('sitename') );
    $siteurl    = $config->get( 'siteurl', JURI::root() );
    
    $recipients = $this->_getAdmins();
    $mailer =JFactory::getMailer();
    
    $subject = JText::sprintf('J2STORE_CITRUS_EMAIL_PAYMENT_NOT_VALIDATED_SUBJECT', $sitename);
    
    foreach ($recipients as $recipient)
    {
      $mailer = JFactory::getMailer();
      $mailer->addRecipient( $recipient->email );
      
      $mailer->setSubject( $subject );
      $mailer->setBody( JText::sprintf('J2STORE_CITRUS_EMAIL_PAYMENT_FAILED_BODY', $recipient->name, $sitename, $siteurl, $message, $paymentData) );
      $mailer->setSender(array( $mailfrom, $fromname ));
      $sent = $mailer->send();
    }
    
    return true;
  }
  
  //AA - Done
  /**
   * Gets admins data
   *
   * @return array|boolean
   * @access protected
   */
  function _getAdmins()
  {
    $db =JFactory::getDBO();
    $query = $db->getQuery(true);
    $query->select('u.name,u.email');
    $query->from('#__users AS u');
    $query->join('LEFT', '#__user_usergroup_map AS ug ON u.id=ug.user_id');
    $query->where('u.sendEmail = 1');
    $query->where('ug.group_id = 8');
    
    $db->setQuery($query);
    $admins = $db->loadObjectList();
    if ($error = $db->getErrorMsg()) {
      JError::raiseError(500, $error);
      return false;
    }
    
    return $admins;
  }
  
  //AA - Done
  function _getOrderId($order_id) {
    
    $db = JFactory::getDBO();
    $query = 'SELECT id FROM #__j2store_orders WHERE order_id='.$db->quote($order_id);
    $db->setQuery($query);
    return $db->loadResult();
    
  }
  
  //AA - Done
  function _getOrderInfo($orderpayment_id) {
    
    //chaged table name from __j2store_orderinfo to __j2store_orderinfos -> added 's' at the end
    
    $db = JFactory::getDBO();
    $query = 'SELECT * FROM #__j2store_orderinfos WHERE j2store_orderinfo_id='.$db->Quote($orderpayment_id);
    $db->setQuery($query);
    return $db->loadObject();
  }
}
