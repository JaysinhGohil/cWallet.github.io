This module contains integration with Citrus Payment Gateway


Here a rule that allows redirect to citrus upon adding a product to
cart:

{ "rules_redirect_to_citrus_on_add_to_cart" : {
    "LABEL" : "Redirect to citrus on add to cart",
    "PLUGIN" : "reaction rule",
    "REQUIRES" : [
      "commerce_shipping",
      "commerce_citrus",
      "commerce_order",
      "commerce_payment",
      "commerce_cart"
    ],
    "ON" : [ "commerce_cart_product_add" ],
    "DO" : [
      { "commerce_shipping_method_collect_rates" : {
          "shipping_method_name" : "flat_rate",
          "commerce_order" : [ "commerce_order" ]
        }
      },
      { "commerce_shipping_delete_shipping_line_items" : { "commerce_order" : [ "commerce_order" ] } },
      { "commerce_citrus_add_shipping" : { "commerce_order" : [ "commerce_order" ] } },
      { "commerce_order_update_status" : {
          "commerce_order" : [ "commerce_order" ],
          "order_status" : "checkout_payment"
        }
      },
      { "commerce_payment_enable_citrus" : {
          "commerce_order" : [ "commerce_order" ],
          "payment_method" : { "value" : {
              "method_id" : "citrus",
              "settings" : {
                "business" : "1234567890",
                "language" : "en",
                "demo" : 0,
                "skip_landing" : 1,
                "one_page_checkout" : 1,
                "one_line" : 0,
                "tangible" : 1,
                "logging" : ""
              }
            }
          }
        }
      },
      { "commerce_citrus_redirect" : { "commerce_order" : [ "commerce_order" ] } }
    ]
  }
}
