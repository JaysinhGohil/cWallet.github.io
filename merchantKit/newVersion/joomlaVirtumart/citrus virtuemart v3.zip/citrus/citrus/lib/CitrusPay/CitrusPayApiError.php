<?php

class CitrusPay_ApiError extends CitrusPay_Error
{
}
