<?php

defined('_JEXEC') or die('Direct Access to ' . basename(__FILE__) . 'is not allowed.');


/**
 *
 *
 * @author Anurag Agarwal
 * @author Sujoy Goswami
 * @version $Id: citrus.php 2 2015-03-15 14:00:00Z alatak $
 * @package VirtueMart
 * @subpackage payment
 * @copyright Copyright (C) 2013-2013 Viatech - All rights reserved.
 */

if (!class_exists('VmConfig')) {
  require(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_virtuemart' . DS . 'helpers' . DS . 'config.php');
}

if (!class_exists ('vmPSPlugin')) {
  require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');
}

set_include_path(VMPATH_ROOT . DS . 'plugins' . DS . 'vmpayment' . DS . 'citrus' . DS . 'citrus' . DS . 'lib'.PATH_SEPARATOR.get_include_path());

require_once("citrus/lib/CitrusPay.php");
require_once("citrus/lib/Zend/Crypt/Hmac.php");


class plgVmPaymentCitrus extends vmPSPlugin {

  // instance of class
  public static $_this = FALSE;


  function __construct (& $subject, $config) {

    parent::__construct ($subject, $config);

    $this->_loggable = TRUE;
    $this->tableFields = array_keys ($this->getTableSQLFields ());
    $this->_tablepkey = 'id'; 
    $this->_tableId = 'id'; 
    $varsToPush =  $this->getVarsToPush ();
    $this->setConfigParameterable ($this->_configTableFieldName, $varsToPush);

    if (!JFactory::getApplication()->isSite()) {
      JFactory::getDocument()->addStyleSheet(JURI::root(true) . '/plugins/vmpayment/citrus/citrus-admin.css');
    }
  }


  /**
   * @return string
   */
  public function getVmPluginCreateTableSQL () {

    return $this->createTableSQL ('Payment Citrus Table');
  }


  /**
   * @return array
   */
  function getTableSQLFields () {

    $SQLfields = array(
      'id'                                     => 'int(11) UNSIGNED NOT NULL AUTO_INCREMENT',
      'virtuemart_order_id'                    => 'int(1) UNSIGNED',
      'order_number'                           => 'char(64)',
      'virtuemart_paymentmethod_id'            => 'mediumint(1) UNSIGNED',
      'payment_name'                           => 'varchar(5000)',
      'payment_order_total'                    => 'decimal(15,5) NOT NULL',
      'payment_currency'                       => 'smallint(1)',
      'cost_per_transaction'                   => 'decimal(10,2)',
      'cost_percent_total'                     => 'decimal(10,2)',
      'tax_id'                                 => 'smallint(1)',
      'citrus_custom'                          => 'varchar(255)',
      'citrus_response_amount'                 => 'decimal(10,2)',
      'citrus_response_pgtxnn'                 => 'char(75)',
      );
    return $SQLfields;
  }


  /**
   * @param $cart
   * @param $order
   * @return bool|null
   */
  function plgVmConfirmedOrder ($cart, $order) {

    if (!($method = $this->getVmPluginMethod ($order['details']['BT']->virtuemart_paymentmethod_id))) {
      return NULL; // Another method was selected, do nothing
    }
    if (!$this->selectedThisElement ($method->payment_element)) {
      return FALSE;
    }
    
    $session = JFactory::getSession ();
    $return_context = $session->getId ();
    //$this->_debug = $method->debug;
    $this->_debug = false;
    $this->logInfo ('plgVmConfirmedOrder order number: ' . $order['details']['BT']->order_number, 'message');

    if (!class_exists ('VirtueMartModelOrders')) {
      require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
    }
    if (!class_exists ('VirtueMartModelCurrency')) {
      require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'currency.php');
    }

    //vendor details
    if (!class_exists ('TableVendors')) {
      require(JPATH_VM_ADMINISTRATOR . DS . 'table' . DS . 'vendors.php');
    }
    $vendorModel = VmModel::getModel ('Vendor');
    $vendorModel->setId (1);
    $vendor = $vendorModel->getVendor ();
    $vendorModel->addImages ($vendor, 1);
    
    //currency details
    $this->getPaymentCurrency ($method);
    $currency_code_3 = shopFunctions::getCurrencyByID ($method->payment_currency, 'currency_code_3');
    $paymentCurrency = CurrencyDisplay::getInstance ($method->payment_currency);
    $totalInPaymentCurrency = round ($paymentCurrency->convertCurrencyTo ($method->payment_currency, $order['details']['BT']->order_total, FALSE), 2);
    $cd = CurrencyDisplay::getInstance ($cart->pricesCurrency);
    
    if ($totalInPaymentCurrency <= 0) {
      vmInfo (JText::_ ('VMPAYMENT_CITRUS_PAYMENT_AMOUNT_INCORRECT'));
      return FALSE;
    }
    
    $quantity = 0;
    foreach ($cart->products as $key => $product) {
      $quantity = $quantity + $product->quantity;
    }

    $address = ((isset($order['details']['ST'])) ? $order['details']['ST'] : $order['details']['BT']);
    
    $addressline = $address->address_1;
    if (isset($address->address_2))
      $addressline = $addressline . $address->address_2;
    
    CitrusPay::setApiKey($method->secret_key, $method->sandbox);        
    $vanityUrl = $method->vanityurl;
    $currency = $currency_code_3;	
    $merchantTxnId = $order['details']['BT']->order_number;
    $orderAmount =$totalInPaymentCurrency;		
    $data = "$vanityUrl$orderAmount$merchantTxnId$currency";
    $secSignature = $this->generateHmacKey($data,CitrusPay::getApiKey());
    $action = CitrusPay::getCPBase()."$vanityUrl"; 
    
    
    $post_variables = Array(
      "transactionId" => $order['details']['BT']->order_number,
      "merchantTxnId" => $order['details']['BT']->order_number,
      "merchantAccessKey" => $method->access_key,
      "orderAmount"           => $totalInPaymentCurrency,
      "currency"    => $currency_code_3,
      "firstName"       => $address->first_name,
      "lastName"        => $address->last_name,
      "addressStreet1"         => $addressline,
      "addressZip"              => $address->zip,
      "addressCity"             => $address->city,
      "addressState"            => isset($address->virtuemart_state_id) ? ShopFunctions::getStateByID ($address->virtuemart_state_id) : '',
      "addressCountry"          => ShopFunctions::getCountryByID ($address->virtuemart_country_id, 'country_2_code'),
      "email"            => $order['details']['BT']->email,
      "phoneNumber"            => $address->phone_1,
      "paymentMode" => 'NET_BANKING',
      "returnUrl"           => JROUTE::_ (JURI::root () . 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&on=' . $order['details']['BT']->order_number . '&pm=' . $order['details']['BT']->virtuemart_paymentmethod_id . '&Itemid=' . JRequest::getInt ('Itemid')),
      "notify_url"       => JROUTE::_ (JURI::root () . 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginnotification&tmpl=component'),
      "cancel_return"    => JROUTE::_ (JURI::root () . 'index.php?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&on=' . $order['details']['BT']->order_number . '&pm=' . $order['details']['BT']->virtuemart_paymentmethod_id . '&Itemid=' . JRequest::getInt ('Itemid')),
      "reqtime" =>  time()*1000,
      "secSignature" => $secSignature
      );

    
    // Prepare data that should be stored in the database
    $dbValues['order_number'] = $order['details']['BT']->order_number;
    $dbValues['payment_name'] = $this->renderPluginName ($method, $order);
    $dbValues['virtuemart_paymentmethod_id'] = $cart->virtuemart_paymentmethod_id;
    $dbValues['cost_per_transaction'] = $method->cost_per_transaction;
    $dbValues['cost_percent_total'] = $method->cost_percent_total;
    $dbValues['payment_currency'] = $method->payment_currency;
    $dbValues['payment_order_total'] = $totalInPaymentCurrency;
    $dbValues['tax_id'] = $method->tax_id;
    $this->storePSPluginInternalData ($dbValues);

    //Submit the results 
    $html = '<html><head><title>Redirection</title></head><body><div style="margin: auto; text-align: left;">';
    $html .= "<div id='result' style='display:none;'>";
    $html .= "<iframe name='form_result'></iframe>";
    $html .= "<br/><br/>";
    $html .= "</div>";
    $html .= "<div class='citrus_msg' style='margin: 10px 0px 10px 0px;'>";
    $html .=  JText::_ ('VMPAYMENT_CITRUS_REDIRECT_DISPLAY_MESSAGE');
    $html .= "</div>";
    $html .= "<form action='".$action."' method='POST' name='transactionForm' id='transactionForm'>";
    $html .= '<input type="submit"  value="' . JText::_ ('VMPAYMENT_CITRUS_REDIRECT_MESSAGE') . '" />';
    foreach ($post_variables as $name => $value) {
      $html .= '<input type="hidden" name="' . $name . '" value="' . htmlspecialchars ($value) . '" />';
    }
    $html .= '</form>';
    $html .= '<script type="text/javascript">';
    $html .= 'document.transactionForm.submit();';
    $html .= '</script></body></html>';

    // 	2 = don't delete the cart, don't send email and don't redirect
    $cart->_confirmDone = FALSE;
    $cart->_dataValidated = FALSE;
    $cart->setCartIntoSession ();
    JRequest::setVar ('html', $html);

  }


  function generateHmacKey($data, $apiKey=null){
    $hmackey = Zend_Crypt_Hmac::compute($apiKey, "sha1", $data);
    return $hmackey;
  }	


  /**
   * @param $virtuemart_paymentmethod_id
   * @param $paymentCurrencyId
   * @return bool|null
   */
  function plgVmgetPaymentCurrency ($virtuemart_paymentmethod_id, &$paymentCurrencyId) {

    if (!($method = $this->getVmPluginMethod ($virtuemart_paymentmethod_id))) {
      return NULL; // Another method was selected, do nothing
    }
    if (!$this->selectedThisElement ($method->payment_element)) {
      return FALSE;
    }
    $this->getPaymentCurrency ($method);
    $paymentCurrencyId = $method->payment_currency;
  }

  /**
  * @param $html
  * @return bool|null|string
  */
  function plgVmOnPaymentResponseReceived (&$html) {

    if (!class_exists ('VirtueMartCart')) {
      require(JPATH_VM_SITE . DS . 'helpers' . DS . 'cart.php');
    }
    if (!class_exists ('shopFunctionsF')) {
      require(JPATH_VM_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');
    }
    if (!class_exists ('VirtueMartModelOrders')) {
      require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
    }

    $virtuemart_paymentmethod_id = JRequest::getInt ('pm', 0);
    $order_number = JRequest::getString ('on', 0);
    $vendorId = 0;
    if (!($method = $this->getVmPluginMethod ($virtuemart_paymentmethod_id))) {
      return NULL; // Another method was selected, do nothing
    }
    if (!$this->selectedThisElement ($method->payment_element)) {
      return NULL;
    }

    if (!($virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($order_number))) {
      return NULL;
    }
    if (!($paymentTable = $this->getDataByOrderId ($virtuemart_order_id))) {
      return '';
    }
    
    $payment_name = $this->renderPluginName ($method);      
    $modelOrder = VmModel::getModel ('orders');
    
    $data = JRequest::get ('request');
    
    if (strcmp ($data['TxStatus'], 'SUCCESS') == 0) { // validate response
      
      $dat=$data['TxId'].$data['TxStatus'].$data['amount'].$data['pgTxnNo'].$data['issuerRefNo'].$data['authIdCode'].$data['firstName'].$data['lastName'].$data['pgRespCode'].$data['addressZip'];
      $respSig=$data['signature'];
      CitrusPay::setApiKey($method->secret_key, $method->sandbox);        
      if ($respSig != $this->generateHmacKey($dat,CitrusPay::getApiKey())) return NULL;
    }
    
    if (strcmp ($data['TxStatus'], 'SUCCESS') == 0) {
      // now we can process the payment
      $order['order_status'] = 'C';           //$method->status_success;
      $order['comments'] = JText::sprintf ('VMPAYMENT_CITRUS_PAYMENT_STATUS_CONFIRMED', $order_number);  
      $order['customer_notified'] = 1;     
      $html = $this->_getPaymentResponseHtml ($paymentTable, $payment_name, JText::_ ('VMPAYMENT_CITRUS_PAYMENT_STATUS_DISPLAY_SUCCESS'));
    } else {        
      $order['order_status'] = 'P';           //$method->status_canceled;
      $order['comments'] = JText::sprintf ('VMPAYMENT_CITRUS_PAYMENT_STATUS_CANCELLED', $order_number);    
      $order['customer_notified'] = 0;
      $html = $this->_getPaymentResponseHtml ($paymentTable, $payment_name, JText::_ ('VMPAYMENT_CITRUS_PAYMENT_STATUS_DISPLAY_FAILURE'));
    }
    
    $this->storeCitrusInternalData ($method, $data, $virtuemart_order_id, $paymentTable->virtuemart_paymentmethod_id, $paymentTable->id);

    $modelOrder->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);
    
    //We delete the old stuff
    // get the correct cart / session
    $cart = VirtueMartCart::getCart ();
    $cart->emptyCart ();
    return TRUE;
  }

  
  /**
   * @return bool|null
   */
  function plgVmOnUserPaymentCancel () {

    if (!class_exists ('VirtueMartModelOrders')) {
      require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
    }

    $order_number = JRequest::getString ('on', '');
    $virtuemart_paymentmethod_id = JRequest::getInt ('pm', '');
    if (empty($order_number) or empty($virtuemart_paymentmethod_id) or !$this->selectedThisByMethodId ($virtuemart_paymentmethod_id)) {
      return NULL;
    }
    if (!($virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($order_number))) {
      return NULL;
    }
    if (!($paymentTable = $this->getDataByOrderId ($virtuemart_order_id))) {
      return NULL;
    }

    VmInfo (Jtext::_ ('VMPAYMENT_CITRUS_PAYMENT_CANCELLED'));
    $session = JFactory::getSession ();
    $return_context = $session->getId ();
    $this->handlePaymentUserCancel ($virtuemart_order_id);
    
    return TRUE;
  }

  
  /*
  	 *   plgVmOnPaymentNotification() - This event is fired by Offline Payment. It can be used to validate the payment data as entered by the user.
  	 * Return:
  	 * Parameters:
  	 *  None
  	 *  @author Valerie Isaksen
  	 */

  /**
   * @return bool|null
   */
  function plgVmOnPaymentNotification () {

    //$this->_debug = true;
    if (!class_exists ('VirtueMartModelOrders')) {
      require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
    }
    $data = JRequest::get ('post');
    if (!isset($data['TxId'])) {
      return FALSE;
    }

    $order_number = $data['TxId'];
    if (!($virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($data['TxId']))) {
      return FALSE;
    }

    $vendorId = 0;
    if (!($payments = $this->getDatasByOrderId ($virtuemart_order_id))) {
      return FALSE;
    }

    $method = $this->getVmPluginMethod ($payments[0]->virtuemart_paymentmethod_id);
    if (!$this->selectedThisElement ($method->payment_element)) {
      return FALSE;
    }
    $this->_debug = false;
    //$this->_debug = $method->debug;

    $modelOrder = VmModel::getModel ('orders');
    $order = array();


    if (strcmp ($data['TxStatus'], 'SUCCESS') == 0) {
      // now we can process the payment
      $order['order_status'] = 'C';
      $order['comments'] = JText::sprintf ('VMPAYMENT_CITRUS_PAYMENT_STATUS_CONFIRMED', $order_number);       
      $order['customer_notified'] = 1;
    } else {        
      $order['order_status'] = 'P';
      $order['comments'] = JText::sprintf ('VMPAYMENT_CITRUS_PAYMENT_STATUS_CANCELLED', $order_number);    
      $order['customer_notified'] = 0;
    }
    $this->storeCitrusInternalData ($method, $data, $virtuemart_order_id, $payments[0]->virtuemart_paymentmethod_id);
    $this->logInfo ('plgVmOnPaymentNotification return new_status:' . $order['order_status'], 'message');

    $modelOrder->updateStatusForOneOrder ($virtuemart_order_id, $order, TRUE);
    
    $this->emptyCart ($payment->user_session, $order_number);
    
    //die();
  }

  

  /**
   * @param $method
   * @param $data
   * @param $virtuemart_order_id
   */
  function storeCitrusInternalData ($method, $data, $virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_id) {
    
    $response_fields['id'] = $payment_id;
    $response_fields['virtuemart_paymentmethod_id'] = $virtuemart_paymentmethod_id;
    $response_fields['virtuemart_order_id'] = $virtuemart_order_id;
    $response_fields['payment_name'] = $this->renderPluginName ($method);
    $response_fields['citrus_custom'] = $data['TxMsg'];
    $response_fields['order_number'] = $data['TxId'];
    $response_fields['citrus_response_amount'] = $data['amount'];
    $response_fields['citrus_response_pgtxnn'] = $data['pgTxnNo'];

    $this->storePSPluginInternalData ($response_fields, $this->_tablepkey, TRUE);
    
  }

  /**
   * Display stored payment data for an order
   *
   * @see components/com_virtuemart/helpers/vmPSPlugin::plgVmOnShowOrderBEPayment()
   */
  function plgVmOnShowOrderBEPayment ($virtuemart_order_id, $payment_method_id) {

    if (!$this->selectedThisByMethodId ($payment_method_id)) {
      return NULL; // Another method was selected, do nothing
    }

    if (!($paymentTable = $this->getDataByOrderId ($virtuemart_order_id))) {
      return NULL;
    }

    $html = '<table class="adminlist" width="50%">' . "\n";
    $html .= $this->getHtmlHeaderBE ();        
    $first = TRUE;
    $html .= '<tr class="row1"><td>' . JText::_ ('VMPAYMENT_CITRUS_DATE') . '</td><td align="left">' . $paymentTable->created_on . '</td></tr>';        
    $html .= $this->getHtmlRowBE ('VMPAYMENT_CITRUS_PAYMENT_NAME', $paymentTable->payment_name);
    $html .= $this->getHtmlRowBE ('VMPAYMENT_CITRUS_PAYMENT_TXN', $paymentTable->citrus_response_pgtxnn);
    $html .= '</table>' . "\n";
    return $html;
    
  }

  /**
   * @param $citrusTable
   * @param $payment_name
   * @return string
   */
  function _getPaymentResponseHtml ($citrusTable, $payment_name, $status) {
    
    $html = '<table>' . "\n";
    $html .= $this->getHtmlRow ('VMPAYMENT_CITRUS_PAYMENT_NAME', $payment_name);
    $html .= $this->getHtmlRow ('VMPAYMENT_CITRUS_PAYMENT_STATUS_DISPLAY', $status);
    if (!empty($citrusTable)) {
      $html .= $this->getHtmlRow ('VMPAYMENT_CITRUS_ORDER_NUMBER', $citrusTable->order_number);
    }
    $html .= '</table>' . "\n";

    return $html;
  }

  
  /**
   * @param VirtueMartCart $cart
   * @param                $method
   * @param                $cart_prices
   * @return int
   */
  function getCosts (VirtueMartCart $cart, $method, $cart_prices) {

    if (preg_match ('/%$/', $method->cost_percent_total)) {
      $cost_percent_total = substr ($method->cost_percent_total, 0, -1);
    } else {
      $cost_percent_total = $method->cost_percent_total;
    }
    return ($method->cost_per_transaction + ($cart_prices['salesPrice'] * $cost_percent_total * 0.01));
  }

  
  /**
   * Check if the payment conditions are fulfilled for this payment method
   *
   * @param $cart_prices: cart prices
   * @param $payment
   * @return true: if the conditions are fulfilled, false otherwise
   *
   */
  protected function checkConditions ($cart, $method, $cart_prices) {

   
		$this->convert_condition_amount($method);
		$amount = $this->getCartAmount($cart_prices);
		$address = (($cart->ST == 0) ? $cart->BT : $cart->ST);


		//vmdebug('standard checkConditions',  $amount, $cart_prices['salesPrice'],  $cart_prices['salesPriceCoupon']);
    $amount_cond = ($amount >= $method->min_amount AND $amount <= $method->max_amount
      OR
      ($method->min_amount <= $amount AND ($method->max_amount == 0)));
    if (!$amount_cond) {
      return FALSE;
    }
    $countries = array();
    if (!empty($method->countries)) {
      if (!is_array ($method->countries)) {
        $countries[0] = $method->countries;
      } else {
        $countries = $method->countries;
      }
    }

    // probably did not gave his BT:ST address
    if (!is_array ($address)) {
      $address = array();
      $address['virtuemart_country_id'] = 0;
    }

    if (!isset($address['virtuemart_country_id'])) {
      $address['virtuemart_country_id'] = 0;
    }
    if (count ($countries) == 0 || in_array ($address['virtuemart_country_id'], $countries) ) {
      return TRUE;
    }

    return FALSE;
  }

  
  /**
   * @param $method
   */
  function convert ($method) {

    $method->min_amount = (float)$method->min_amount;
    $method->max_amount = (float)$method->max_amount;
  }

  /**
   * We must reimplement this triggers for joomla 1.7
   */

  

  /**
   * Create the table for this plugin if it does not yet exist.
   * This functions checks if the called plugin is active one.
   * When yes it is calling the standard method to create the tables
   *
   * @author Valérie Isaksen
   *
   */
  function plgVmOnStoreInstallPaymentPluginTable ($jplugin_id) {

    return $this->onStoreInstallPluginTable ($jplugin_id);
  }

  
  /**
   * This event is fired after the payment method has been selected. It can be used to store
   * additional payment info in the cart.
   *
   * @author Max Milbers
   * @author Valérie isaksen
   *
   * @param VirtueMartCart $cart: the actual cart
   * @return null if the payment was not selected, true if the data is valid, error message if the data is not vlaid
   *
   */
  public function plgVmOnSelectCheckPayment (VirtueMartCart $cart, &$msg) {

    return $this->OnSelectCheck ($cart);
  }



  /**
   * plgVmDisplayListFEPayment
   * This event is fired to display the pluginmethods in the cart (edit shipment/payment) for exampel
   *
   * @param object  $cart Cart object
   * @param integer $selected ID of the method selected
   * @return boolean True on succes, false on failures, null when this plugin was not selected.
   * On errors, JError::raiseWarning (or JError::raiseError) must be used to set a message.
   *
   * @author Valerie Isaksen
   * @author Max Milbers
   */
  public function plgVmDisplayListFEPayment (VirtueMartCart $cart, $selected = 0, &$htmlIn) {

    return $this->displayListFE ($cart, $selected, $htmlIn);
  }

  /*
  	 * plgVmonSelectedCalculatePricePayment
  	 * Calculate the price (value, tax_id) of the selected method
  	 * It is called by the calculator
  	 * This function does NOT to be reimplemented. If not reimplemented, then the default values from this function are taken.
  	 * @author Valerie Isaksen
  	 * @cart: VirtueMartCart the current cart
  	 * @cart_prices: array the new cart prices
  	 * @return null if the method was not selected, false if the shiiping rate is not valid any more, true otherwise
  	 *
  	 *
  	 */
  

  /**
   * @param VirtueMartCart $cart
   * @param array          $cart_prices
   * @param                $cart_prices_name
   * @return bool|null
   */
  public function plgVmonSelectedCalculatePricePayment (VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name) {

    return $this->onSelectedCalculatePrice ($cart, $cart_prices, $cart_prices_name);
  }

  /**
   * plgVmOnCheckAutomaticSelectedPayment
   * Checks how many plugins are available. If only one, the user will not have the choice. Enter edit_xxx page
   * The plugin must check first if it is the correct type
   *
   * @author Valerie Isaksen
   * @param VirtueMartCart cart: the cart object
   * @return null if no plugin was found, 0 if more then one plugin was found,  virtuemart_xxx_id if only one plugin is found
   *
   */
  function plgVmOnCheckAutomaticSelectedPayment (VirtueMartCart $cart, array $cart_prices = array(), &$paymentCounter) {

    return $this->onCheckAutomaticSelected ($cart, $cart_prices, $paymentCounter);
  }

  
  /**
   * This method is fired when showing the order details in the frontend.
   * It displays the method-specific data.
   *
   * @param integer $order_id The order ID
   * @return mixed Null for methods that aren't active, text (HTML) otherwise
   * @author Max Milbers
   * @author Valerie Isaksen
   */
  public function plgVmOnShowOrderFEPayment ($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name) {

    $this->onShowOrderFE ($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
  }

  
  /**
   * This event is fired during the checkout process. It can be used to validate the
   * method data as entered by the user.
   *
   * @return boolean True when the data was valid, false otherwise. If the plugin is not activated, it should return null.
   * @author Max Milbers

  public function plgVmOnCheckoutCheckDataPayment($psType, VirtueMartCart $cart) {
  return null;
  }
   */

  
  /**
   * This method is fired when showing when priting an Order
   * It displays the the payment method-specific data.
   *
   * @param integer $_virtuemart_order_id The order ID
   * @param integer $method_id  method used for this order
   * @return mixed Null when for payment methods that were not selected, text (HTML) otherwise
   * @author Valerie Isaksen
   */
  function plgVmonShowOrderPrintPayment ($order_number, $method_id) {

    return $this->onShowOrderPrint ($order_number, $method_id);
  }

  function plgVmDeclarePluginParamsPayment ($name, $id, &$data) {

    return $this->declarePluginParams ('payment', $name, $id, $data);
  }

  function plgVmDeclarePluginParamsPaymentVM3( &$data) {
    return $this->declarePluginParams('payment', $data);
  }
  
  /**
   * @param $name
   * @param $id
   * @param $table
   * @return bool
   */
  function plgVmSetOnTablePluginParamsPayment ($name, $id, &$table) {

    return $this->setOnTablePluginParams ($name, $id, $table);
  }

  /**
   * Save updated order data to the method specific table
   *
   * @param array $_formData Form data
   * @return mixed, True on success, false on failures (the rest of the save-process will be
   * skipped!), or null when this method is not actived.
   * @author Oscar van Eijk

  public function plgVmOnUpdateOrderPayment(  $_formData) {
  return null;
  }
   */
  
  /**
   * Save updated orderline data to the method specific table
   *
   * @param array $_formData Form data
   * @return mixed, True on success, false on failures (the rest of the save-process will be
   * skipped!), or null when this method is not actived.
   * @author Oscar van Eijk

  public function plgVmOnUpdateOrderLine(  $_formData) {
  return null;
  }
   */
  
  /**
   * plgVmOnEditOrderLineBE
   * This method is fired when editing the order line details in the backend.
   * It can be used to add line specific package codes
   *
   * @param integer $_orderId The order ID
   * @param integer $_lineId
   * @return mixed Null for method that aren't active, text (HTML) otherwise
   * @author Oscar van Eijk

  public function plgVmOnEditOrderLineBE(  $_orderId, $_lineId) {
  return null;
  }
   */

  
  /**
   * This method is fired when showing the order details in the frontend, for every orderline.
   * It can be used to display line specific package codes, e.g. with a link to external tracking and
   * tracing systems    
   *
   * @param integer $_orderId The order ID
   * @param integer $_lineId
   * @return mixed Null for method that aren't active, text (HTML) otherwise
   * @author Oscar van Eijk

  public function plgVmOnShowOrderLineFE(  $_orderId, $_lineId) {
  return null;
  }
   */
  
  
}

// No closing tag
