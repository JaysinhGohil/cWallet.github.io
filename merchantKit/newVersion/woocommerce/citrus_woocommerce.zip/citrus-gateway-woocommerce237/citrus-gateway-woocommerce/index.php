<?php
/*
Plugin Name: WooCommerce Citrus gateway
Plugin URI: http://viatechs.in/
Description: Extends WooCommerce with Citrus payment gateway. AJAX Version supported.
Version: 1.2
Author: Viatechs
Author URI: http://viatechs.in
Copyright: © 2013-14 Viatechs.
*/

$bd=ABSPATH.'wp-content/plugins/'.dirname( plugin_basename( __FILE__ ) );
set_include_path($bd.'/citrus'.PATH_SEPARATOR.get_include_path());
require_once($bd."/citrus/citruslib.php");

add_action('plugins_loaded', 'woocommerce_citrus_init', 0);

function woocommerce_citrus_init() {

  if ( !class_exists( 'WC_Payment_Gateway' ) ) return;

  /**
   * Localisation
   */
  load_plugin_textdomain('wc-citrus', false, dirname( plugin_basename( __FILE__ ) ) . '/languages');
  
  if($_GET['msg']!=''){
    add_action('the_content', 'showMessage');
  }

  function showMessage($content){
    return '<div class="box '.htmlentities($_GET['type']).'-box">'.htmlentities(urldecode($_GET['msg'])).'</div>'.$content;
  }
  /**
   * Gateway class
   */
  class WC_Citrus extends WC_Payment_Gateway {
    protected $msg = array();
    public function __construct(){
      // Go wild in here
      $this -> id = 'citrus';
      $this -> method_title = __('Citrus', 'citrus');
      $this -> icon = WP_PLUGIN_URL . "/" . plugin_basename(dirname(__FILE__)) . '/images/citrus.png';
      $this -> has_fields = false;
      $this -> init_form_fields();
      $this -> init_settings();
      $this -> title = $this -> settings['title'];
      $this -> description = $this -> settings['description'];
      $this -> gateway_module = $this -> settings['gateway_module'];
      $this -> payment_url = $this -> settings['payment_url'];
      $this -> access_key = $this -> settings['access_key'];
      $this -> api_key = $this -> settings['api_key'];
      $this -> redirect_page_id = $this -> settings['redirect_page_id'];
      $this -> liveurl = 'http://www.citruspay.com';
      $this -> msg['message'] = "";
      $this -> msg['class'] = "";
      add_action('init', array(&$this, 'check_citrus_response'));
      //update for woocommerce >2.0
      add_action( 'woocommerce_api_' . strtolower( get_class( $this ) ), array( $this, 'check_citrus_response' ) );

      add_action('valid-citrus-request', array(&$this, 'SUCCESS'));
      if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {
        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( &$this, 'process_admin_options' ) );
      } else {
        add_action( 'woocommerce_update_options_payment_gateways', array( &$this, 'process_admin_options' ) );
      }
      add_action('woocommerce_receipt_citrus', array(&$this, 'receipt_page'));
      add_action('woocommerce_thankyou_citrus',array(&$this, 'thankyou_page'));
      
    }
    
    function init_form_fields(){

      $this -> form_fields = array(
        'enabled' => array(
            'title' => __('Enable/Disable', 'citrus'),
            'type' => 'checkbox',
            'label' => __('Enable Citrus Payment Module.', 'citrus'),
            'default' => 'no'),
          'title' => array(
            'title' => __('Title:', 'citrus'),
            'type'=> 'text',
            'description' => __('This controls the title which the user sees during checkout.', 'citrus'),
            'default' => __('Citrus', 'citrus')),
          'description' => array(
            'title' => __('Description:', 'citrus'),
            'type' => 'textarea',
            'description' => __('This controls the description which the user sees during checkout.', 'citrus'),
            'default' => __('Pay securely by Credit or Debit card or net banking through Citrus Secure Servers.', 'citrus')),
          'gateway_module' => array(
            'title' => __('Gateway Module', 'citrus'),
            'type' => 'select',
            'options' => array("0"=>"Select","sandbox"=>"Sandbox","staging"=>"Staging","production"=>"Production"),
            'description' => __('Citrus Gateway module as activated by Citruspay.','citrus')
            ),
          'payment_url' => array(
            'title' => __('Payment URL', 'citrus'),
            'type' => 'text',
            'description' =>  __('Payment url (right most part only) as set.', 'citrus')
            ),
          'access_key' => array(
            'title' => __('Access Key', 'citrus'),
            'type' => 'text',
            'description' =>  __('Access Key as configured.', 'citrus')
            ),
          'api_key' => array(
            'title' => __('API Key', 'citrus'),
            'type' => 'text',
            'description' =>  __('Api Key as configured.', 'citrus')
            ),
          'redirect_page_id' => array(
            'title' => __('Return Page'),
            'type' => 'select',
            'options' => $this -> get_pages('Select Page'),
            'description' => "URL of success page"
            )
          );


    }
    
    /**
     * Admin Panel Options
     * - Options for bits like 'title' and availability on a country-by-country basis
     **/
    public function admin_options(){
      echo '<h3>'.__('Citrus Payment Gateway', 'citrus').'</h3>';
      echo '<p>'.__('Citrus is most popular payment gateway for online shopping in India').'</p>';
      echo '<table class="form-table">';
      $this -> generate_settings_html();
      echo '</table>';

    }
    /**
     *  There are no payment fields for Citrus, but we want to show the description if set.
     **/
    function payment_fields(){
      if($this -> description) echo wpautop(wptexturize($this -> description));
    }
    /**
     * Receipt Page
     **/
    function receipt_page($order){
      echo '<p>'.__('Thank you for your order, please click the button below to pay with Citrus.', 'citrus').'</p>';
      echo $this -> generate_citrus_form($order);
    }
    /**
     * Process the payment and return the result
     **/
    function process_payment($order_id){
      $order = new WC_Order($order_id);
      /*return array('result' => 'success', 'redirect' => add_query_arg('order',
        $order->id, add_query_arg('key', $order->order_key, get_permalink(get_option('woocommerce_pay_page_id'))))
          );*/
	  return array('result' => 'success', 'redirect' => add_query_arg('order',
        $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay')))));
    }
    
    /**
     * Check for valid Citrus server callback
     **/    
    function check_Citrus_response(){
      
      global $woocommerce;
      
	  $data="";
	  $status=-1;
	  if(isset($_REQUEST['TxId']) && isset($_REQUEST['TxStatus']))
      {
		  $data.=$_POST['TxId'].$_POST['TxStatus'].$_POST['amount'].$_POST['pgTxnNo'].$_POST['issuerRefNo'].$_POST['authIdCode'].$_POST['firstName'].$_POST['lastName'].$_POST['pgRespCode'].$_POST['addressZip'];
		  $respSig=$_POST['signature'];
		  
		  CitrusLib::setApiKey($this->api_key, $this->gateway_module);
          $sec = CitrusLib::getHmacKey($data);
		  if($respSig != "" && strcmp($sec, $respSig) != 0)
		  {
			  $status=0;
		  }
		  else
		  {
			  $status=1;
		  }
		  
	  }
	  if($status < 1)
	  {
		  $this -> msg['class'] = 'error';
          $this -> msg['message'] = "Attempt to forge transaction...";
	  }
	  
      if($status==1)
      {
        $redirect_url = ($this -> redirect_page_id=="" || $this -> redirect_page_id==0)?get_site_url() . "/":get_permalink($this -> redirect_page_id);
        
        $order_id = explode('_', $_REQUEST['TxId']);
        $order_id = (int)$order_id[0];    //get rid of time part
       
        $this -> msg['class'] = 'error';
        $this -> msg['message'] = "Thank you for shopping with us. However, the transaction has been declined.";
        
        if($order_id != '')
        {
          try
          {
            $order = new WC_Order($order_id);
            $txstatus = $_REQUEST['TxStatus'];
            $txrefno = $_REQUEST['TxRefNo'];
            $txmsg = $_REQUEST['TxMsg'];
            $peymentmode = $_REQUEST['paymentMode'];
            $amount = $_REQUEST['amount'];
            
            $transauthorised = false;
            
            if($order -> status !=='completed')
            {
              if(strcmp($txstatus, 'SUCCESS') == 0)
              {
                  $transauthorised = true;
                  $this -> msg['message'] = "Thank you for shopping with us. Your account has been charged and your transaction is successful. We will be shipping your order to you soon.";
                  $this -> msg['class'] = 'success';
                  if($order -> status == 'processing')
                  {
                    //do nothing
                  }
                  else
                  {
                    //complete the order
                    $order -> payment_complete();
                    $order -> add_order_note('Citrus Payment Gateway has processed the payment. Ref Number: '. $txrefno);
                    $order -> add_order_note($this->msg['message']);
                    $woocommerce -> cart -> empty_cart();
                  }

              }
              else
              {
                  $this -> msg['class'] = 'error';
                  $this -> msg['message'] = "Thank you for shopping with us. However, the transaction has been declined.";
                  //Here you need to put in the routines for a failed
                  //transaction such as sending an email to customer
                  //setting database status etc etc
              }
             
              if ($transauthorised==false)
              {
                $order -> update_status('failed');
                $order -> add_order_note('Failed');
                $order -> add_order_note($this->msg['message']);
              }
              //removed for WooCOmmerce 2.0
              //add_action('the_content', array(&$this, 'showMessage'));
            }
          }
          catch(Exception $e)
          {
            // $errorOccurred = true;
            $msg = "Error";
          }
        }
        
       }
	   
       $redirect_url = ($this -> redirect_page_id=="" || $this -> redirect_page_id==0)?get_site_url() . "/":get_permalink($this -> redirect_page_id);
        //For wooCoomerce 2.0
       $redirect_url = add_query_arg( array('msg'=> urlencode($this -> msg['message']), 'type'=>$this -> msg['class']), $redirect_url );

       wp_redirect( $redirect_url );
       exit;
      
    }
    
    
    
    /*
     //Removed For WooCommerce 2.0
    function showMessage($content){
         return '<div class="box '.$this -> msg['class'].'-box">'.$this -> msg['message'].'</div>'.$content;
     }*/
    
    /**
     * Generate Citrus button link
     **/    
    public function generate_citrus_form($order_id){
      
      global $woocommerce;
      $order = new WC_Order($order_id);
      $redirect_url = ($this -> redirect_page_id=="" || $this -> redirect_page_id==0)?get_site_url() . "/":get_permalink($this -> redirect_page_id);
      
      //For wooCoomerce 2.0
      $redirect_url = add_query_arg( 'wc-api', get_class( $this ), $redirect_url );
      $order_id = $order_id.'_'.date("ymds");
      
      //do we have a phone number?
      //get currency      
      $address = $order -> billing_address_1;
      if ($order -> billing_address_2 != "")
        $address = $address.' '.$order -> billing_address_2;
      
      //Setup URL and signatue etc.
      CitrusLib::setApiKey($this->api_key, $this->gateway_module);
      $vanityUrl = $this->payment_url;
      $currencycode = get_woocommerce_currency();	    
      $merchantTxnId = $order_id;
      $orderAmount = $order -> order_total;		
      $data = "$vanityUrl$orderAmount$merchantTxnId$currencycode";
      $secSignature = CitrusLib::getHmacKey($data);
      $action = CitrusLib::getCpUrl()."$vanityUrl"; 
      
      
      $citrus_args = array(
        'merchantTxnId' => $merchantTxnId,  
        "merchantAccessKey" => $this -> access_key,
        'orderAmount' => $order -> order_total,
        "currency"    => $currencycode,        
        'firstName' => $order -> billing_first_name,
        'lastName' =>  $order -> billing_last_name,
        'addressStreet1' => $address,               
        'addressCity' => $order -> billing_city,
        'addressState' => $order -> billing_state,
        'addressZip' => $order -> shipping_postcode,
        'addressCountry' => $order -> billing_country,        
        'phoneNumber' => $order -> billing_phone,
        'email' => $order -> billing_email,
        "paymentMode" => 'NET_BANKING',
        "reqtime" =>  time()*1000,
        "secSignature" => $secSignature,
        "returnUrl" => $redirect_url        
        );

      $citrus_args_array = array();
      foreach($citrus_args as $key => $value){
        $citrus_args_array[] = "<input type='hidden' name='$key' value='$value'/>";
      }
      return '<form action="'.$action.'" method="post" id="citrus_payment_form">
                ' . implode('', $citrus_args_array) . '
                <input type="submit" class="button-alt" id="submit_citrus_payment_form" value="'.'Pay via Citrus'.'" /> <a class="button cancel" href="'.$order->get_cancel_order_url().'">'.'Cancel order &amp; restore cart'.'</a>
                <script type="text/javascript">
        jQuery(function(){
        jQuery("body").block(
            {
                message: "<img src=\"'.$woocommerce->plugin_url().'/assets/images/ajax-loader.gif\" alt=\"Redirecting…\" style=\"float:left; margin-right: 10px;\" />'.'Thank you for your order. We are now redirecting you to Citrus Payment Gateway to make payment.'.'",
                    overlayCSS:
            {
                background: "#fff",
                    opacity: 0.6
          },
        css: {
            padding:        20,
                textAlign:      "center",
                color:          "#555",
                border:         "3px solid #aaa",
                backgroundColor:"#fff",
                cursor:         "wait",
                lineHeight:"32px"
        }
        });
        jQuery("#submit_citrus_payment_form").click();

        });
      </script>
      </form>';
    }
    
        
    function get_pages($title = false, $indent = true) {
      $wp_pages = get_pages('sort_column=menu_order');
      $page_list = array();
      if ($title) $page_list[] = $title;
      foreach ($wp_pages as $page) {
        $prefix = '';
        // show indented child pages?
        if ($indent) {
          $has_parent = $page->post_parent;
          while($has_parent) {
            $prefix .=  ' - ';
            $next_page = get_page($has_parent);
            $has_parent = $next_page->post_parent;
          }
        }
        // add to page list array array
        $page_list[$page->ID] = $prefix . $page->post_title;
      }
      return $page_list;
    }

  }

  /**
   * Add the Gateway to WooCommerce
   **/
  function woocommerce_add_citrus_gateway($methods) {
    $methods[] = 'WC_Citrus';
    return $methods;
  }

  add_filter('woocommerce_payment_gateways', 'woocommerce_add_citrus_gateway' );
}

?>
