=== Plugin Name ===
Developed By: Viatechs
Tags: WooCommerce, Payment Gateway, Citrus

Tested platform - Wordpress 4.1.1, Woocommerce 2.3.7


Allows you to use Citrus payment gateway with the WooCommerce plugin.

== Description ==

This is the Citrus payment gateway extension for WooCommerce. Allows you to use Citrus payment gateway with the WooCommerce plugin. It uses the Citrus payment url for payment so that you don't have to install an SSL certificate on your site.

== Installation ==
1. Ensure you have latest version of WooCommerce plugin installed
2. Unzip and upload contents of the plugin to your /wp-content/plugins/ directory OR go to Wordpress plugins page, then Add New and Upload the extension zip.
3. Activate the plugin through the 'Plugins' menu in WordPress


== Configuration ==

1. Visit the WooCommerce settings page, and click on the Payment Gateways tab.
2. Click on Citrus to edit the settings. If you do not see Citrus in the list at the top of the screen make sure you have activated the plugin in the WordPress Plugin Manager.
3. Enable the Payment Method.



