<?php
if(!isset($_REQUEST['TxStatus'])){
set_include_path('../modules/citrus/lib/'.PATH_SEPARATOR.'modules/citrus/lib/'.PATH_SEPARATOR.get_include_path());

require_once("CitrusPay.php");
require_once("Zend/Crypt/Hmac.php");
}

class citrus extends PaymentModule
{
	function __construct()
	{
		$this->name = 'citrus';
		$this->tab = 'payments_gateways';
		$this->version = 1.0;		
		
		parent::__construct();
		/* The parent construct is required for translations */
		$this->page = basename(__FILE__, '.php');
		$this->displayName = $this->l('Citrus');
		$this->description = $this->l('Accept payments by Citrus');
	}
	
	function install()
	{
		if(parent::install()){
			$sid = $this->getOrderState();
			$fid =$this->getOrderState()+1;
			
			Configuration::updateValue('citrus_vanityurl', '');
			Configuration::updateValue('citrus_access_key', '');			
			Configuration::updateValue('citrus_api_key','');
			Configuration::updateValue('citrus_mode', '');
			Configuration::updateValue('CITRUS_ID_ORDER_SUCCESS',$sid);
			Configuration::updateValue('CITRUS_ID_ORDER_FAILED',$fid);
									
			$this->registerHook('payment');
			
			Db::getInstance()->Execute
			('
				INSERT INTO `' . _DB_PREFIX_ . 'order_state`
			( `id_order_state`,`invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`)
				VALUES
			('.$sid.',0, 0, \'#33FF99\', 0, 0,0);
			');
			Db::getInstance()->Execute
				('
					INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` 
				(`id_order_state`, `id_lang`, `name`, `template`) 
					VALUES 
				('.$sid.', 1, \'Payment accepted\', \'payment\')');
				
			
			Db::getInstance()->Execute
			('
				INSERT INTO `' . _DB_PREFIX_ . 'order_state`
			( `id_order_state`,`invoice`, `send_email`, `color`, `unremovable`, `logable`, `delivery`)
				VALUES
			('.$fid.',0, 0, \'#33FF99\', 0, 0,0);
			');
			Db::getInstance()->Execute
				('
					INSERT INTO `' . _DB_PREFIX_ . 'order_state_lang` 
				(`id_order_state`, `id_lang`, `name`, `template`) 
					VALUES 
				('.$fid.', 1, \'Payment Failed\', \'payment\')');
			
			
			
			return true;
		}else 
			return false;		
	}
	
	public function uninstall()
	{		
		Db::getInstance()->Execute
				('
					DELETE FROM `' . _DB_PREFIX_ . 'order_state_lang` 
					 WHERE id_order_state = '.Configuration::get('CITRUS_ID_ORDER_SUCCESS').' and id_lang = 1' );
		Db::getInstance()->Execute
				('
					DELETE FROM `' . _DB_PREFIX_ . 'order_state_lang` 
					 WHERE id_order_state = '.Configuration::get('CITRUS_ID_ORDER_FAILED').' and id_lang = 1');
				
		
		if (!Configuration::deleteByName('citrus_vanityurl') OR
			!Configuration::deleteByName('citrus_access_key') OR
			!Configuration::deleteByName('citrus_api_key') OR 
			!Configuration::deleteByName('citrus_mode') OR 
			!Configuration::deleteByName('CITRUS_ID_ORDER_SUCCESS') OR
			!Configuration::deleteByName('CITRUS_ID_ORDER_FAILED') OR
			!parent::uninstall())
			return false;
		return true;
	}
	
	//pri:backend display
	public function displayForm()
	{
		$this->_html .= '
		<img src="../modules/citrus/citrus.gif" style="float:left; padding: 10px 0px; margin-right:15px;" />
		<b>'.$this->l('This module allows you to accept payments by Citrus.').'</b><br /><br />
		'.$this->l('If the client chooses this payment mode, your Citrus account will be automatically credited.').'<br />
		'.$this->l('You need to configure your Citrus account first before using this module.').'
		<br /><br /><br />';
	}
	
	public function displayFormSettings()
	{
		$conf = Configuration::getMultiple(array('citrus_vanityurl',
												'citrus_access_key',
												'citrus_api_key',
												'citrus_mode'));
												
		$citrus_vanityurl = array_key_exists('citrus_vanityurl', $_POST) ? $_POST['citrus_vanityurl'] : (array_key_exists('citrus_vanityurl', $conf) ? $conf['citrus_vanityurl'] : '');
		$citrus_access_key = array_key_exists('citrus_access_key', $_POST) ? $_POST['citrus_access_key'] : (array_key_exists('citrus_access_key', $conf) ? $conf['citrus_access_key'] : '');
		$citrus_api_key = array_key_exists('citrus_api_key', $_POST) ? $_POST['citrus_api_key'] : (array_key_exists('citrus_api_key', $conf) ? $conf['citrus_api_key'] : '');
		$citrus_mode = array_key_exists('citrus_mode', $_POST) ? $_POST['citrus_mode'] : (array_key_exists('citrus_mode', $conf) ? $conf['citrus_mode'] : '');	
		
		$this->_html .= '
		<form action="'.$_SERVER['REQUEST_URI'].'" name="submitcitrus" method="post">
		<fieldset>
			<legend><img src="../img/admin/contact.gif" />'.$this->l('Settings').'</legend>
			
			<label>'.$this->l('Payment Page URL').'</label>
			<div class="margin-form"><input type="text" name="citrus_vanityurl" value="'.$citrus_vanityurl.'" size="33" /></div>
			
			<label>'.$this->l('Access Key').'</label>
			<div class="margin-form"><input type="text" size="33" name="citrus_access_key" value="'.$citrus_access_key.'" /></div>
			
			<label>'.$this->l('Secret Key').'</label>
			<div class="margin-form"><input type="text" size="33" name="citrus_api_key" value="'.$citrus_api_key.'" /></div>
			
			<label for="citrus_mode">'.$this->l('Gateway Module').'</label>
			
			  <div class="margin-form" id="authorizeaim_demo">
					
					<input type="radio" name="citrus_mode" value="production" style="vertical-align: middle;"'.(($citrus_mode=='production')? 'checked="checked"' : '').'/>					
					<span style="color: #080;">'.$this->l('Production').'</span>
					
					<input type="radio" name="citrus_mode" value="sandbox" style="vertical-align: middle;"'.(($citrus_mode=='sandbox')? 'checked="checked"' : '').'/>
					<span style="color: #900;">'.$this->l('Sandbox').'</span>
					
					<input type="radio" name="citrus_mode" value="staging" style="vertical-align: middle;"'.(($citrus_mode=='staging')? 'checked="checked"' : '').'/>
					<span>'.$this->l('Staging').'</span>
			 </div>
			 
			</div>
			<br /><center><input style=" cursor:pointer" type="submit" name="submitcitrus" value="'.$this->l('Update settings').'" class="button" /></center>
		</fieldset>
		</form><br /><br />
		';
	}	
	
	public function displayErrors()
	{
		$nbErrors = sizeof($this->_postErrors);
		$this->_html .= '
		<div class="alert error">
			<h3>'.($nbErrors > 1 ? $this->l('There are') : $this->l('There is')).' '.$nbErrors.' '.($nbErrors > 1 ? $this->l('errors') : $this->l('error')).'</h3>
			<ol>';
		foreach ($this->_postErrors AS $error)
			$this->_html .= '<li>'.$error.'</li>';
		$this->_html .= '
			</ol>
		</div>';
	}
	
	public function displayConf()
	{
		$this->_html .= '
		<div class="conf confirm">
			<img src="../img/admin/ok.gif" alt="'.$this->l('Confirmation').'" />
			'.$this->l('Settings updated').'
		</div>';
	}
	//pri:backend display-End
	
	public function getOrderState()
	{

			$id=Db::getInstance()->getRow
			('
				SELECT max(id_order_state) as id FROM `' . _DB_PREFIX_ . 'order_state`
			');

			$id['id']++;
			return $id['id'];

		
	}
	
	//pri:backend code
	public function getContent()
	{
		$this->_html = '<h2></h2>';
		if (isset($_POST['submitcitrus']))
		{
			if (empty($_POST['citrus_vanityurl']))
				$this->_postErrors[] = $this->l('Vanity Url is required.');
			if (empty($_POST['citrus_access_key']))
				$this->_postErrors[] = $this->l('Merchant access key is required.');
			if (empty($_POST['citrus_api_key']))
				$this->_postErrors[] = $this->l('Api key is required.');			
				
			if (!sizeof($this->_postErrors))
			{
				Configuration::updateValue('citrus_vanityurl', $_POST['citrus_vanityurl']);
				Configuration::updateValue('citrus_access_key', $_POST['citrus_access_key']);
				Configuration::updateValue('citrus_api_key', $_POST['citrus_api_key']);
				Configuration::updateValue('citrus_mode', $_POST['citrus_mode']);				
				$this->displayConf();
			}
			else
				$this->displayErrors();
		
		}
		$this->displayForm();
		$this->displayFormSettings();
		return $this->_html;
	}
	//pro:backend code-End
	
	function generateHmacKey($data, $apiKey=null){
		$hmackey = Zend_Crypt_Hmac::compute($apiKey, "sha1", $data);
		return $hmackey;
	}
	
	public function hookPayment($params)
	{
		global $smarty,$cart;				
		
		$customer = new Customer($cart->id_customer);	
		$address = new Address($cart->id_address_invoice);			
		$state=new State($address->id_state);
		$country=new Country($address->id_country);		
			
		$citrus_vanityurl= Configuration::get('citrus_vanityurl');
		$citrus_access_key= Configuration::get('citrus_access_key');
		$citrus_api_key= Configuration::get('citrus_api_key');
		$citrus_mode= Configuration::get('citrus_mode');
		
		$id_currency = intval(Configuration::get('PS_CURRENCY_DEFAULT'));
		$currency = new Currency(intval($id_currency));
		
		//Required for Citrus		
		CitrusPay::setApiKey($citrus_api_key,$citrus_mode);		
		$currency_code =$currency->iso_code;	
		$merchantTxnId = rand();
		$issuerCode = ''; //not req but donot remove		
		$orderAmount =number_format(Tools::convertPrice($cart->getOrderTotal(),$currency), 2, '.', '');
		
		$data = "$citrus_vanityurl$orderAmount$merchantTxnId$currency_code";
		
		$secSignature = $this->generateHmacKey($data,CitrusPay::getApiKey());
		$action = CitrusPay::getCPBase()."$citrus_vanityurl";  
		
		//End of Citrus	
		
		$smarty->assign(array(
            'action' => $action,
			'merchantAccessKey' => $citrus_access_key,
			'merchantTxnId' => $merchantTxnId,
			'orderAmount' => $orderAmount,
			'secSignature' => $secSignature,
			'currency' => $currency_code,
			'customer' => $customer,
			'address' => $address,
			'country' => $country->iso_code,
			'state' => $state->name,
			'return_url' => 'http://'.htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT, 'UTF-8').__PS_BASE_URI__.'modules/citrus/thank-you.php?cart_id='.intval($cart->id),
            'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://').htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT, 'UTF-8').__PS_BASE_URI__.'modules/'.$this->name.'/',
			'reqtime' => time() . '000',
        ));

        return $this->display(__FILE__, 'citrus.tpl');
    }
    
    /**
	 * Attempts to finalize an accepted transaction
	 *
	 * @response will contain SUCCESS
	 * @cart_id will contain the cart id
	 */
    public function finalizeOrder($response,$cart_id,$amount)
    {			
    	global $smarty, $cart, $cookie;

		$cart = new Cart($cart_id);		
		if($response == 'SUCCESS')
		{
			$responseMsg="Your Order has Been Processed";
			$status=Configuration::get('CITRUS_ID_ORDER_SUCCESS');
		}
		else 
		{
			$responseMsg="Transaction Failed, Retry!!";
			$status=Configuration::get('CITRUS_ID_ORDER_FAILED');
		}	
	
		$this->validateOrder($cart_id, $status, $amount, $this->displayName);
			
		$smarty->assign(array('this_path' => $this->_path,
					'responseMsg'	=> $responseMsg,
					'this_path_ssl' => (Configuration::get('PS_SSL_ENABLED') ? 'https://' : 'http://').htmlspecialchars($_SERVER['HTTP_HOST'], ENT_COMPAT, 'UTF-8').__PS_BASE_URI__.'modules/'.$this->name.'/'
					));
		
    }
}
?>