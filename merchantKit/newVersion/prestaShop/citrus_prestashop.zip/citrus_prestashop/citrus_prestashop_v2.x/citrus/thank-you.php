<? /* Prestashop payment module for Citrus Payment Gateway */ ?>
<?php 
$useSSL = true;
require_once(dirname(__FILE__).'/../../config/config.inc.php');
require_once(dirname(__FILE__).'/../../header.php');
require_once(dirname(__FILE__).'/citrus.php');
$rsp=$_REQUEST['TxStatus'];
$amount=$_REQUEST['amount'];
$cart_id=$_REQUEST['cart_id'];
$obj=new citrus();
$obj->finalizeOrder($rsp,$cart_id,$amount);
$smarty->display(dirname(__FILE__).'/thank-you.tpl');
include(dirname(__FILE__).'/../../footer.php');
?>
