<?php

/*****************************************************
* Citruspay PHP class for encryption functions       *
* Developed by: Viatechs.in                          *
* Date: 08/07/2013                                   *
* Version: 1.0.1                                     *
* Compatibility: PHP 5.2 and higher                  *  
* Copyright: Distribution and usage of this          *
* library is reserved. User must obtain permission   *
* from Viatechs.in to use or distribute this library.*
*****************************************************/


abstract class CitrusLib
{
	//private constants
	const SANDBOX_API_URL='https://sandboxadmin.citruspay.com/api/v1/txn/';
	const SANDBOX_PMT_URL='https://sandbox.citruspay.com/';
	
	const STAGING_API_URL='https://stgadmin.citruspay.com/api/v1/txn/';
	const STAGING_PMT_URL='https://stg.citruspay.com/';
	
	const PRODUCTION_API_URL='https://admin.citruspay.com/api/v1/txn/';
	const PRODUCTION_PMT_URL='https://www.citruspay.com/';
	
	//variables
	public static $apiKey;
	public static $env;
	public static $apiUrl;
	public static $cpUrl;


	//public methods
	public static function setApiKey($apiKey,$env)
	{
		self::$apiKey = $apiKey;
		self::$env = $env;
		switch($env)
		{
		case 'sandbox':
			self::$apiUrl = self::SANDBOX_API_URL;
			self::$cpUrl = self::SANDBOX_PMT_URL;
			break;
		case 'staging':
			self::$apiUrl = self::STAGING_API_URL;
			self::$cpUrl = self::STAGING_PMT_URL;
			break;
		case 'production':
			self::$apiUrl = self::PRODUCTION_API_URL;
			self::$cpUrl = self::PRODUCTION_PMT_URL;
			break;
		}
	}
  
  
	public static function getApiUrl()
	{
		return self::$apiUrl;
	}
  
	public static function getCpUrl()
	{
		return self::$cpUrl;
	}
  
	public static function getHmacKey($data){
		$hmac=hash_hmac('sha1',$data,self::$apiKey);
		return $hmac;
	}	
} // End of CitrusLib class... by Viatechs.in 08/07/2013 All Rights Reserved

