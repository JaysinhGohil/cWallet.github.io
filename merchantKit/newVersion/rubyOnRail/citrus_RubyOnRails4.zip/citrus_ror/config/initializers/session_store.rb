# Be sure to restart your server when you modify this file.

CitrusRor::Application.config.session_store :cookie_store, key: '_citrus_ror_session'
