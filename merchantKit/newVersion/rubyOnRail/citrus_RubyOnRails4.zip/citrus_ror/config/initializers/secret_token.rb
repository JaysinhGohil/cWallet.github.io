# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
CitrusRor::Application.config.secret_key_base = '73d495b1cdfa16fa36ae17f1c1251f3eb56179e767de4183816bc020dd28a88294721f1ec95c072ae4a1fd77fc4c49837439af114a3e6946b61ffcab5f984b1a'
