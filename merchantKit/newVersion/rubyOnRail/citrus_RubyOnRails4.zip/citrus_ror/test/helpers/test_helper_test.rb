require 'test_helper'

class TestHelperTest < ActionView::TestCase
end
