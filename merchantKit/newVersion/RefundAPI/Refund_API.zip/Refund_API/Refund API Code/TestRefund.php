﻿<?php 

set_include_path('../lib'.PATH_SEPARATOR.get_include_path());
require_once('../lib/Citruspay.php');
	$secretKey = "9cb8adb33795e314dc48615cd2187f23d007e"; // Needs to be change with your secret key
	$merchantAccessKey = "SBBMAR9NQ3KWK5B3B";  // Needs to be change with your access key
	$transactionId = "9185983506"; //Needs to be change with your merchant transaction id
	$pgTxnId = "78296361751060"; // Needs to be change with your
	$RRN = "5106923918";  // Needs to be change with your RRN
	$authIdCode = "9999"; // Needs to be change with your Auth code
	$currencyCode = "INR"; 
	$txnType = "R"; 
	$amount = "1.00"; // Needs to be change with your refund amount
			    
	$tarr = array(
			"merchantAccessKey" => $merchantAccessKey,
			"transactionId" => $transactionId,
			"pgTxnId" => $pgTxnId,
			"RRN" => $RRN,
			"authIdCode" => $authIdCode,
			"currencyCode" => $currencyCode,
			"txnType" => $txnType,
			"amount" => $amount			
	);

	CitrusPay::setApiKey($secretKey,'sandbox'); //Change "sandbox" to "production" once you go live.	
	$response = Refund::create($tarr,CitrusPay::getApiKey());
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Test Refund</title>
</head>
<body>		 	 						
	<?php
			if ($response -> get_resp_code() == 200) {
				echo "<p>Response Code : " . $response -> get_resp_code() . "</p>";
				echo "<p>Response Message : " . $response -> get_resp_msg() . "</p>";
				echo "<p>Transaction ID : " . $response -> get_txn_id() . "</p>";
				echo "<p>PG Transaction ID : " . $response -> get_pg_txn_id() . "</p>";
				echo "<p>Auth ID Code : " . $response -> get_auth_id_code() . "</p>";
				echo "<p>RRN : " . $response -> get_rrn() . "</p>";
				echo "<p>Amount : " . $response -> get_amount() . "</p>";
			} else {
				echo "<p>Response Code : " . $response -> get_resp_code() . "</p>";
				echo "<p>Response Message : " . $response -> get_resp_msg() . "</p>";
			}
	 ?>
				 
</body>
</html>
